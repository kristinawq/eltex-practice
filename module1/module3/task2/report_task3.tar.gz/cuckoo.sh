#!/bin/bash

PARAM=$1

if [ -z "$PARAM" ]; then
    echo "Ошибка: укажите --pishitesuda=/путь/к/каналу"
    exit 1
fi

PIPE_PATH=$(echo "$PARAM" | cut -d'=' -f2)

mkfifo "$PIPE_PATH"

log_msg() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> cuckoo.log
}

log_msg "Startup!"

trap 'log_msg "Shutdown!"; rm -f "$PIPE_PATH"; exit 0' SIGTERM

while true; do
    if read line < "$PIPE_PATH"; then
        NAME_PID=$(echo "$line" | cut -d':' -f1)
        N=$((RANDOM % 9 + 2))
        log_msg "$NAME_PID $N"
        echo "$N" > "$PIPE_PATH"
    fi
done
