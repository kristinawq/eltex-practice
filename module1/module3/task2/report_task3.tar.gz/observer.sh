#!/bin/bash

CONFIG_FILE="observer.conf"

if [ ! -f "$CONFIG_FILE" ]; then
    echo "Файл $CONFIG_FILE не найден!"
    exit 1
fi

while IFS= read -r script_path; do
    [ -z "$script_path" ] && continue

    script_name=$(basename "$script_path")

    is_running=$(ps -ef | grep -v "grep" | grep -v "observer.sh" | grep "$script_name" | head -n 1)
    if [ -z "$is_running" ]; then
        echo "$(date '+%Y-%m-%d %H:%M:%S') Скрипт $script_name не найден" >> observer.log
        
        nohup "$script_path" > /dev/null 2>&1 &
    else
        echo "$(date '+%Y-%m-%d %H:%M:%S') Скрипт $script_name работает" >> observer.log
    fi

done < "$CONFIG_FILE"
