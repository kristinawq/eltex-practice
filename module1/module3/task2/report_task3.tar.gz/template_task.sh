#!/bin/bash

exec > /dev/null 2>&1

SCRIPT_NAME=$(basename "$0")

if [ "$SCRIPT_NAME" == "template_task.sh" ]; then
    echo "Я бригадир, сам не работаю"
    exit 1
fi

REPORT_FILE="report_${SCRIPT_NAME}.log"

while true; do
    echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] Скрипт запущен" >> "$REPORT_FILE"
    
    echo "${SCRIPT_NAME}[$$]: how much time do I have?" > /tmp/cuckoo_pipe
    read N < /tmp/cuckoo_pipe
    
    sleep "$N"
    
    echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] Скрипт завершил цикл, работал $N секунд" >> "$REPORT_FILE"
done
